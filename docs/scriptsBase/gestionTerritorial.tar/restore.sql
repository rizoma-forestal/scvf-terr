--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.3.13
-- Dumped by pg_dump version 9.5.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.usuario DROP CONSTRAINT fk_usuario_rol_id;
ALTER TABLE ONLY public.usuario DROP CONSTRAINT fk_usuario_admin_id;
ALTER TABLE ONLY public.regionesxprovincias DROP CONSTRAINT fk_regionesxprovincias_region_fk;
ALTER TABLE ONLY public.regionesxprovincias DROP CONSTRAINT fk_regionesxprovincias_provincia_fk;
ALTER TABLE ONLY public.region DROP CONSTRAINT fk_region_especificidadderegion_id;
ALTER TABLE ONLY public.region DROP CONSTRAINT fk_region_adminentidad_id;
ALTER TABLE ONLY public.provincia DROP CONSTRAINT fk_provincia_adminentidad_id;
ALTER TABLE ONLY public.municipio DROP CONSTRAINT fk_municipio_provincia_id;
ALTER TABLE ONLY public.municipio DROP CONSTRAINT fk_municipio_departamento_id;
ALTER TABLE ONLY public.municipio DROP CONSTRAINT fk_municipio_adminentidad_id;
ALTER TABLE ONLY public.especificidadderegion DROP CONSTRAINT fk_especificidadderegion_adminentidad_id;
ALTER TABLE ONLY public.departamento DROP CONSTRAINT fk_departamento_provincia_id;
ALTER TABLE ONLY public.departamento DROP CONSTRAINT fk_departamento_adminentidad_id;
ALTER TABLE ONLY public.centropobladotipo DROP CONSTRAINT fk_centropobladotipo_adminentidad_id;
ALTER TABLE ONLY public.centropoblado DROP CONSTRAINT fk_centropoblado_departamento_id;
ALTER TABLE ONLY public.centropoblado DROP CONSTRAINT fk_centropoblado_centropobladotipo_id;
ALTER TABLE ONLY public.centropoblado DROP CONSTRAINT fk_centropoblado_adminentidad_id;
ALTER TABLE ONLY public.usuario DROP CONSTRAINT usuario_pkey;
ALTER TABLE ONLY public.usuario DROP CONSTRAINT usuario_nombre_key;
ALTER TABLE ONLY public.sequence DROP CONSTRAINT sequence_pkey;
ALTER TABLE ONLY public.rol DROP CONSTRAINT rol_pkey;
ALTER TABLE ONLY public.rol DROP CONSTRAINT rol_nombre_key;
ALTER TABLE ONLY public.regionesxprovincias DROP CONSTRAINT regionesxprovincias_pkey;
ALTER TABLE ONLY public.region DROP CONSTRAINT region_pkey;
ALTER TABLE ONLY public.provincia DROP CONSTRAINT provincia_pkey;
ALTER TABLE ONLY public.municipio DROP CONSTRAINT municipio_pkey;
ALTER TABLE ONLY public.localidad DROP CONSTRAINT localidad_pkey;
ALTER TABLE ONLY public.localidad DROP CONSTRAINT localidad_nombre_key;
ALTER TABLE ONLY public.localidad DROP CONSTRAINT localidad_codigopostal_key;
ALTER TABLE ONLY public.especificidadderegion DROP CONSTRAINT especificidadderegion_pkey;
ALTER TABLE ONLY public.departamento DROP CONSTRAINT departamento_pkey;
ALTER TABLE ONLY public.centropobladotipo DROP CONSTRAINT centropobladotipo_pkey;
ALTER TABLE ONLY public.centropoblado DROP CONSTRAINT centropoblado_pkey;
ALTER TABLE ONLY public.adminentidad DROP CONSTRAINT adminentidad_pkey;
ALTER TABLE public.usuario ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.rol ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.region ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.provincia ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.municipio ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.localidad ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.especificidadderegion ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.departamento ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.centropobladotipo ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.centropoblado ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.adminentidad ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.usuario_id_seq;
DROP TABLE public.usuario;
DROP TABLE public.sequence;
DROP SEQUENCE public.rol_id_seq;
DROP TABLE public.rol;
DROP TABLE public.regionesxprovincias;
DROP SEQUENCE public.region_id_seq;
DROP TABLE public.region;
DROP SEQUENCE public.provincia_id_seq;
DROP VIEW public.munis;
DROP VIEW public.muniindec3;
DROP VIEW public.muniindec2;
DROP VIEW public.muniindec;
DROP TABLE public.municipios;
DROP SEQUENCE public.municipio_id_seq;
DROP VIEW public.muni;
DROP TABLE public.provincia;
DROP TABLE public.municipiosindec;
DROP TABLE public.municipio;
DROP SEQUENCE public.localidad_id_seq;
DROP TABLE public.localidad;
DROP SEQUENCE public.especificidadderegion_id_seq;
DROP TABLE public.especificidadderegion;
DROP SEQUENCE public.departamento_id_seq;
DROP TABLE public.departamento;
DROP SEQUENCE public.centropobladotipo_id_seq;
DROP TABLE public.centropobladotipo;
DROP SEQUENCE public.centropoblado_id_seq;
DROP TABLE public.centropoblado;
DROP SEQUENCE public.adminentidad_id_seq;
DROP TABLE public.adminentidad;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: adminentidad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE adminentidad (
    id integer NOT NULL,
    fechaalta date NOT NULL,
    fechabaja date,
    fechamodif date,
    habilitado boolean,
    usalta_id bigint NOT NULL,
    usbaja_id bigint,
    usmodif_id bigint
);


ALTER TABLE adminentidad OWNER TO postgres;

--
-- Name: adminentidad_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE adminentidad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE adminentidad_id_seq OWNER TO postgres;

--
-- Name: adminentidad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE adminentidad_id_seq OWNED BY adminentidad.id;


--
-- Name: centropoblado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE centropoblado (
    id integer NOT NULL,
    nombre character varying(255),
    centropobladotipo_id bigint,
    departamento_id bigint,
    adminentidad_id bigint
);


ALTER TABLE centropoblado OWNER TO postgres;

--
-- Name: centropoblado_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE centropoblado_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE centropoblado_id_seq OWNER TO postgres;

--
-- Name: centropoblado_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE centropoblado_id_seq OWNED BY centropoblado.id;


--
-- Name: centropobladotipo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE centropobladotipo (
    id integer NOT NULL,
    nombre character varying(255),
    adminentidad_id bigint
);


ALTER TABLE centropobladotipo OWNER TO postgres;

--
-- Name: centropobladotipo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE centropobladotipo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE centropobladotipo_id_seq OWNER TO postgres;

--
-- Name: centropobladotipo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE centropobladotipo_id_seq OWNED BY centropobladotipo.id;


--
-- Name: departamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE departamento (
    id integer NOT NULL,
    nombre character varying(255),
    provincia_id bigint,
    adminentidad_id bigint
);


ALTER TABLE departamento OWNER TO postgres;

--
-- Name: departamento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE departamento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE departamento_id_seq OWNER TO postgres;

--
-- Name: departamento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE departamento_id_seq OWNED BY departamento.id;


--
-- Name: especificidadderegion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE especificidadderegion (
    id integer NOT NULL,
    nombre character varying(255),
    adminentidad_id bigint
);


ALTER TABLE especificidadderegion OWNER TO postgres;

--
-- Name: especificidadderegion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE especificidadderegion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE especificidadderegion_id_seq OWNER TO postgres;

--
-- Name: especificidadderegion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE especificidadderegion_id_seq OWNED BY especificidadderegion.id;


--
-- Name: localidad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE localidad (
    id integer NOT NULL,
    codigopostal character varying(10) NOT NULL,
    nombre character varying(50) NOT NULL
);


ALTER TABLE localidad OWNER TO postgres;

--
-- Name: localidad_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE localidad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE localidad_id_seq OWNER TO postgres;

--
-- Name: localidad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE localidad_id_seq OWNED BY localidad.id;


--
-- Name: municipio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE municipio (
    id integer NOT NULL,
    nombre character varying(255),
    departamento_id bigint,
    provincia_id bigint,
    adminentidad_id bigint
);


ALTER TABLE municipio OWNER TO postgres;

--
-- Name: municipiosindec; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE municipiosindec (
    municipio text,
    departamento text,
    prov_id integer,
    muni_cod text,
    tipo text
);


ALTER TABLE municipiosindec OWNER TO postgres;

--
-- Name: provincia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE provincia (
    id integer NOT NULL,
    nombre character varying(255),
    adminentidad_id bigint,
    prov_id integer
);


ALTER TABLE provincia OWNER TO postgres;

--
-- Name: muni; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW muni AS
 SELECT rtrim(ltrim((m.nombre)::text)) AS municipios_nuestros_mayusculas,
    p.id AS id_provincia1,
    mi.prov_id AS id_provincia2,
    rtrim(ltrim(upper(translate(mi.municipio, 'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜ'::text, 'aeiouAEIOUaeiouAEIOU'::text)))) AS municipios_del_indec_mayusculas
   FROM ((municipiosindec mi
     LEFT JOIN provincia p ON ((mi.prov_id = p.prov_id)))
     LEFT JOIN municipio m ON (((rtrim(ltrim((m.nombre)::text)) = rtrim(ltrim(upper(translate(mi.municipio, 'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜ'::text, 'aeiouAEIOUaeiouAEIOU'::text))))) AND (p.id = m.provincia_id))));


ALTER TABLE muni OWNER TO postgres;

--
-- Name: municipio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE municipio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE municipio_id_seq OWNER TO postgres;

--
-- Name: municipio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE municipio_id_seq OWNED BY municipio.id;


--
-- Name: municipios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE municipios (
    idmunicipio integer,
    nombre text,
    idprovincia integer
);


ALTER TABLE municipios OWNER TO postgres;

--
-- Name: muniindec; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW muniindec AS
 SELECT p.id AS provincia_id,
    rtrim(ltrim(upper(translate(mi.departamento, 'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜ'::text, 'aeiouAEIOUaeiouAEIOU'::text)))) AS departamento,
    rtrim(ltrim(upper(translate(mi.municipio, 'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜ'::text, 'aeiouAEIOUaeiouAEIOU'::text)))) AS municipio
   FROM (municipiosindec mi
     JOIN provincia p ON ((mi.prov_id = p.prov_id)));


ALTER TABLE muniindec OWNER TO postgres;

--
-- Name: muniindec2; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW muniindec2 AS
 SELECT m.provincia_id,
    m.id AS muni_id,
    mi.departamento,
    mi.municipio
   FROM (municipio m
     JOIN muniindec mi ON (((mi.provincia_id = m.provincia_id) AND (rtrim(ltrim((m.nombre)::text)) = rtrim(ltrim(mi.municipio))))));


ALTER TABLE muniindec2 OWNER TO postgres;

--
-- Name: muniindec3; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW muniindec3 AS
 SELECT mi2.muni_id AS municipio_id,
    d.id AS departamento_id
   FROM (muniindec2 mi2
     JOIN departamento d ON (((mi2.provincia_id = d.provincia_id) AND (rtrim(ltrim((d.nombre)::text)) = rtrim(ltrim(mi2.departamento))))));


ALTER TABLE muniindec3 OWNER TO postgres;

--
-- Name: munis; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW munis AS
 SELECT rtrim(ltrim((m.nombre)::text)) AS municipios_nuestros_mayusculas,
    p.prov_id AS id_provincia1,
    mi.prov_id AS id_provincia2,
        CASE
            WHEN (mi.prov_id IS NULL) THEN 0
            ELSE mi.prov_id
        END AS field_alias,
    rtrim(ltrim(upper(translate(mi.municipio, 'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜ'::text, 'aeiouAEIOUaeiouAEIOU'::text)))) AS municipios_del_indec_mayusculas
   FROM ((municipiosindec mi
     JOIN provincia p ON ((mi.prov_id = p.prov_id)))
     RIGHT JOIN municipio m ON (((rtrim(ltrim((m.nombre)::text)) = rtrim(ltrim(upper(translate(mi.municipio, 'áéíóúÁÉÍÓÚäëïöüÄËÏÖÜ'::text, 'aeiouAEIOUaeiouAEIOU'::text))))) AND (p.id = m.provincia_id))));


ALTER TABLE munis OWNER TO postgres;

--
-- Name: provincia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE provincia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE provincia_id_seq OWNER TO postgres;

--
-- Name: provincia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE provincia_id_seq OWNED BY provincia.id;


--
-- Name: region; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE region (
    id integer NOT NULL,
    nombre character varying(255),
    especificidadderegion_id bigint,
    adminentidad_id bigint
);


ALTER TABLE region OWNER TO postgres;

--
-- Name: region_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE region_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE region_id_seq OWNER TO postgres;

--
-- Name: region_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE region_id_seq OWNED BY region.id;


--
-- Name: regionesxprovincias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE regionesxprovincias (
    provincia_fk bigint NOT NULL,
    region_fk bigint NOT NULL
);


ALTER TABLE regionesxprovincias OWNER TO postgres;

--
-- Name: rol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE rol (
    id integer NOT NULL,
    nombre character varying(255),
    adminentidad_id bigint
);


ALTER TABLE rol OWNER TO postgres;

--
-- Name: rol_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE rol_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE rol_id_seq OWNER TO postgres;

--
-- Name: rol_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE rol_id_seq OWNED BY rol.id;


--
-- Name: sequence; Type: TABLE; Schema: public; Owner: webservices
--

CREATE TABLE sequence (
    seq_name character varying(50) NOT NULL,
    seq_count numeric(38,0)
);


ALTER TABLE sequence OWNER TO webservices;

--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE usuario (
    id integer NOT NULL,
    nombre character varying(20) NOT NULL,
    rol_id bigint,
    admin_id bigint,
    nombrecompleto character varying(100)
);


ALTER TABLE usuario OWNER TO postgres;

--
-- Name: usuario_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE usuario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE usuario_id_seq OWNER TO postgres;

--
-- Name: usuario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE usuario_id_seq OWNED BY usuario.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY adminentidad ALTER COLUMN id SET DEFAULT nextval('adminentidad_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY centropoblado ALTER COLUMN id SET DEFAULT nextval('centropoblado_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY centropobladotipo ALTER COLUMN id SET DEFAULT nextval('centropobladotipo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY departamento ALTER COLUMN id SET DEFAULT nextval('departamento_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY especificidadderegion ALTER COLUMN id SET DEFAULT nextval('especificidadderegion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY localidad ALTER COLUMN id SET DEFAULT nextval('localidad_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY municipio ALTER COLUMN id SET DEFAULT nextval('municipio_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY provincia ALTER COLUMN id SET DEFAULT nextval('provincia_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY region ALTER COLUMN id SET DEFAULT nextval('region_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY rol ALTER COLUMN id SET DEFAULT nextval('rol_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuario ALTER COLUMN id SET DEFAULT nextval('usuario_id_seq'::regclass);


--
-- Data for Name: adminentidad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY adminentidad (id, fechaalta, fechabaja, fechamodif, habilitado, usalta_id, usbaja_id, usmodif_id) FROM stdin;
\.
COPY adminentidad (id, fechaalta, fechabaja, fechamodif, habilitado, usalta_id, usbaja_id, usmodif_id) FROM '$$PATH$$/2961.dat';

--
-- Name: adminentidad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('adminentidad_id_seq', 13939, true);


--
-- Data for Name: centropoblado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY centropoblado (id, nombre, centropobladotipo_id, departamento_id, adminentidad_id) FROM stdin;
\.
COPY centropoblado (id, nombre, centropobladotipo_id, departamento_id, adminentidad_id) FROM '$$PATH$$/2963.dat';

--
-- Name: centropoblado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('centropoblado_id_seq', 10894, true);


--
-- Data for Name: centropobladotipo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY centropobladotipo (id, nombre, adminentidad_id) FROM stdin;
\.
COPY centropobladotipo (id, nombre, adminentidad_id) FROM '$$PATH$$/2965.dat';

--
-- Name: centropobladotipo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('centropobladotipo_id_seq', 10, true);


--
-- Data for Name: departamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY departamento (id, nombre, provincia_id, adminentidad_id) FROM stdin;
\.
COPY departamento (id, nombre, provincia_id, adminentidad_id) FROM '$$PATH$$/2967.dat';

--
-- Name: departamento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('departamento_id_seq', 535, true);


--
-- Data for Name: especificidadderegion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY especificidadderegion (id, nombre, adminentidad_id) FROM stdin;
\.
COPY especificidadderegion (id, nombre, adminentidad_id) FROM '$$PATH$$/2969.dat';

--
-- Name: especificidadderegion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('especificidadderegion_id_seq', 9, true);


--
-- Data for Name: localidad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY localidad (id, codigopostal, nombre) FROM stdin;
\.
COPY localidad (id, codigopostal, nombre) FROM '$$PATH$$/2971.dat';

--
-- Name: localidad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('localidad_id_seq', 4, true);


--
-- Data for Name: municipio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY municipio (id, nombre, departamento_id, provincia_id, adminentidad_id) FROM stdin;
\.
COPY municipio (id, nombre, departamento_id, provincia_id, adminentidad_id) FROM '$$PATH$$/2973.dat';

--
-- Name: municipio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('municipio_id_seq', 4557, true);


--
-- Data for Name: municipios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY municipios (idmunicipio, nombre, idprovincia) FROM stdin;
\.
COPY municipios (idmunicipio, nombre, idprovincia) FROM '$$PATH$$/2984.dat';

--
-- Data for Name: municipiosindec; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY municipiosindec (municipio, departamento, prov_id, muni_cod, tipo) FROM stdin;
\.
COPY municipiosindec (municipio, departamento, prov_id, muni_cod, tipo) FROM '$$PATH$$/2985.dat';

--
-- Data for Name: provincia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY provincia (id, nombre, adminentidad_id, prov_id) FROM stdin;
\.
COPY provincia (id, nombre, adminentidad_id, prov_id) FROM '$$PATH$$/2975.dat';

--
-- Name: provincia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('provincia_id_seq', 24, true);


--
-- Data for Name: region; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY region (id, nombre, especificidadderegion_id, adminentidad_id) FROM stdin;
\.
COPY region (id, nombre, especificidadderegion_id, adminentidad_id) FROM '$$PATH$$/2977.dat';

--
-- Name: region_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('region_id_seq', 32, true);


--
-- Data for Name: regionesxprovincias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY regionesxprovincias (provincia_fk, region_fk) FROM stdin;
\.
COPY regionesxprovincias (provincia_fk, region_fk) FROM '$$PATH$$/2979.dat';

--
-- Data for Name: rol; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY rol (id, nombre, adminentidad_id) FROM stdin;
\.
COPY rol (id, nombre, adminentidad_id) FROM '$$PATH$$/2980.dat';

--
-- Name: rol_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('rol_id_seq', 5, true);


--
-- Data for Name: sequence; Type: TABLE DATA; Schema: public; Owner: webservices
--

COPY sequence (seq_name, seq_count) FROM stdin;
\.
COPY sequence (seq_name, seq_count) FROM '$$PATH$$/2986.dat';

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usuario (id, nombre, rol_id, admin_id, nombrecompleto) FROM stdin;
\.
COPY usuario (id, nombre, rol_id, admin_id, nombrecompleto) FROM '$$PATH$$/2982.dat';

--
-- Name: usuario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('usuario_id_seq', 8, true);


--
-- Name: adminentidad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY adminentidad
    ADD CONSTRAINT adminentidad_pkey PRIMARY KEY (id);


--
-- Name: centropoblado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY centropoblado
    ADD CONSTRAINT centropoblado_pkey PRIMARY KEY (id);


--
-- Name: centropobladotipo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY centropobladotipo
    ADD CONSTRAINT centropobladotipo_pkey PRIMARY KEY (id);


--
-- Name: departamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY departamento
    ADD CONSTRAINT departamento_pkey PRIMARY KEY (id);


--
-- Name: especificidadderegion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY especificidadderegion
    ADD CONSTRAINT especificidadderegion_pkey PRIMARY KEY (id);


--
-- Name: localidad_codigopostal_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY localidad
    ADD CONSTRAINT localidad_codigopostal_key UNIQUE (codigopostal);


--
-- Name: localidad_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY localidad
    ADD CONSTRAINT localidad_nombre_key UNIQUE (nombre);


--
-- Name: localidad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY localidad
    ADD CONSTRAINT localidad_pkey PRIMARY KEY (id);


--
-- Name: municipio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY municipio
    ADD CONSTRAINT municipio_pkey PRIMARY KEY (id);


--
-- Name: provincia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY provincia
    ADD CONSTRAINT provincia_pkey PRIMARY KEY (id);


--
-- Name: region_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY region
    ADD CONSTRAINT region_pkey PRIMARY KEY (id);


--
-- Name: regionesxprovincias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY regionesxprovincias
    ADD CONSTRAINT regionesxprovincias_pkey PRIMARY KEY (provincia_fk, region_fk);


--
-- Name: rol_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY rol
    ADD CONSTRAINT rol_nombre_key UNIQUE (nombre);


--
-- Name: rol_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY rol
    ADD CONSTRAINT rol_pkey PRIMARY KEY (id);


--
-- Name: sequence_pkey; Type: CONSTRAINT; Schema: public; Owner: webservices
--

ALTER TABLE ONLY sequence
    ADD CONSTRAINT sequence_pkey PRIMARY KEY (seq_name);


--
-- Name: usuario_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT usuario_nombre_key UNIQUE (nombre);


--
-- Name: usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id);


--
-- Name: fk_centropoblado_adminentidad_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY centropoblado
    ADD CONSTRAINT fk_centropoblado_adminentidad_id FOREIGN KEY (adminentidad_id) REFERENCES adminentidad(id);


--
-- Name: fk_centropoblado_centropobladotipo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY centropoblado
    ADD CONSTRAINT fk_centropoblado_centropobladotipo_id FOREIGN KEY (centropobladotipo_id) REFERENCES centropobladotipo(id);


--
-- Name: fk_centropoblado_departamento_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY centropoblado
    ADD CONSTRAINT fk_centropoblado_departamento_id FOREIGN KEY (departamento_id) REFERENCES departamento(id);


--
-- Name: fk_centropobladotipo_adminentidad_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY centropobladotipo
    ADD CONSTRAINT fk_centropobladotipo_adminentidad_id FOREIGN KEY (adminentidad_id) REFERENCES adminentidad(id);


--
-- Name: fk_departamento_adminentidad_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY departamento
    ADD CONSTRAINT fk_departamento_adminentidad_id FOREIGN KEY (adminentidad_id) REFERENCES adminentidad(id);


--
-- Name: fk_departamento_provincia_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY departamento
    ADD CONSTRAINT fk_departamento_provincia_id FOREIGN KEY (provincia_id) REFERENCES provincia(id);


--
-- Name: fk_especificidadderegion_adminentidad_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY especificidadderegion
    ADD CONSTRAINT fk_especificidadderegion_adminentidad_id FOREIGN KEY (adminentidad_id) REFERENCES adminentidad(id);


--
-- Name: fk_municipio_adminentidad_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY municipio
    ADD CONSTRAINT fk_municipio_adminentidad_id FOREIGN KEY (adminentidad_id) REFERENCES adminentidad(id);


--
-- Name: fk_municipio_departamento_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY municipio
    ADD CONSTRAINT fk_municipio_departamento_id FOREIGN KEY (departamento_id) REFERENCES departamento(id);


--
-- Name: fk_municipio_provincia_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY municipio
    ADD CONSTRAINT fk_municipio_provincia_id FOREIGN KEY (provincia_id) REFERENCES provincia(id);


--
-- Name: fk_provincia_adminentidad_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY provincia
    ADD CONSTRAINT fk_provincia_adminentidad_id FOREIGN KEY (adminentidad_id) REFERENCES adminentidad(id);


--
-- Name: fk_region_adminentidad_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY region
    ADD CONSTRAINT fk_region_adminentidad_id FOREIGN KEY (adminentidad_id) REFERENCES adminentidad(id);


--
-- Name: fk_region_especificidadderegion_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY region
    ADD CONSTRAINT fk_region_especificidadderegion_id FOREIGN KEY (especificidadderegion_id) REFERENCES especificidadderegion(id);


--
-- Name: fk_regionesxprovincias_provincia_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY regionesxprovincias
    ADD CONSTRAINT fk_regionesxprovincias_provincia_fk FOREIGN KEY (provincia_fk) REFERENCES provincia(id);


--
-- Name: fk_regionesxprovincias_region_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY regionesxprovincias
    ADD CONSTRAINT fk_regionesxprovincias_region_fk FOREIGN KEY (region_fk) REFERENCES region(id);


--
-- Name: fk_usuario_admin_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT fk_usuario_admin_id FOREIGN KEY (admin_id) REFERENCES adminentidad(id);


--
-- Name: fk_usuario_rol_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT fk_usuario_rol_id FOREIGN KEY (rol_id) REFERENCES rol(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

